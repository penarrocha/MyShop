<nav class="hidden md:flex space-x-8">
    <a href="<?php echo e(route('welcome')); ?>" class="text-gray-700 hover:text-primary-600 transition <?php echo e(request()->routeIs('welcome') ? 'text-primary-600 font-semibold' : ''); ?>">Inicio</a>
    <a href="<?php echo e(route('products.index')); ?>" class="text-gray-700 hover:text-primary-600 transition <?php echo e(request()->routeIs('products.*') ? 'text-primary-600 font-semibold' : ''); ?>">Productos</a>
    <a href="<?php echo e(route('categories.index')); ?>" class="text-gray-700 hover:text-primary-600 transition <?php echo e(request()->routeIs('categories.*') ? 'text-primary-600 font-semibold' : ''); ?>">Categorías</a>
    <a href="<?php echo e(route('offers.index')); ?>" class="text-gray-700 hover:text-primary-600 transition <?php echo e(request()->routeIs('offers.*') ? 'text-primary-600 font-semibold' : ''); ?>">Ofertas</a>
    <a href="<?php echo e(route('contact')); ?>" class="text-gray-700 hover:text-primary-600 transition <?php echo e(request()->routeIs('contact') ? 'text-primary-600 font-semibold' : ''); ?>">Contacto</a>
    <?php if(auth()->guard()->check()): ?>
    <a href="<?php echo e(route('account.index')); ?>" class="text-gray-700 hover:text-primary-600 transition <?php echo e(request()->routeIs('account.*') || request()->routeIs('profile.*') ? 'text-primary-600 font-semibold' : ''); ?>">Mi cuenta</a>
    <?php if(auth()->user()->hasRole('admin')): ?>
    <a href="<?php echo e(route('admin.products.index')); ?>"
        class="text-gray-700 hover:text-primary-600 transition <?php echo e(request()->routeIs('admin.*') ? 'text-primary-600 font-semibold' : ''); ?>">
        Administración
    </a>
    <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
    <a href="<?php echo e(route('login')); ?>" class="text-gray-700 hover:text-primary-600 transition <?php echo e(request()->routeIs('login') ? 'text-primary-600 font-semibold' : ''); ?>">Login</a>
    <?php endif; ?>
</nav><?php /**PATH /var/www/html/resources/views/partials/public/navigation.blade.php ENDPATH**/ ?>