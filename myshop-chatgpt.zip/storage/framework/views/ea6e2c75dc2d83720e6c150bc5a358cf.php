
<?php if(session()->has('success') || session()->has('error') || session()->has('info')): ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
    <?php if(session('success')): ?>
    <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded-md shadow-sm">
        <p class="font-bold">✓ Éxito</p>
        <p><?php echo e(session('success')); ?></p>
    </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md shadow-sm">
        <p class="font-bold">✗ Error</p>
        <p><?php echo e(session('error')); ?></p>
    </div>
    <?php endif; ?>

    <?php if(session('info')): ?>
    <div class="bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 rounded-md shadow-sm">
        <p class="font-bold">ⓘ Información</p>
        <p><?php echo e(session('info')); ?></p>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/partials/shared/flash-messages.blade.php ENDPATH**/ ?>