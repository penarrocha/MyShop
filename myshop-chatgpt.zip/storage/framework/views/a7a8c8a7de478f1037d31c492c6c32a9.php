<div class="bg-white rounded-lg shadow-lg p-6 category-card cursor-pointer <?php echo e($class); ?>">
    <div class="text-4xl text-primary-500 mb-4 h-48 overflow-hidden">
        <a href="<?php echo e(route('categories.show', $category)); ?>" class="text-primary-600 font-semibold hover:text-primary-700 transition"><?php if (isset($component)) { $__componentOriginala40248e8bccff36c9e094fa8227c7bfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala40248e8bccff36c9e094fa8227c7bfa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'cloudinary::components.image','data' => ['publicId' => $category->image,'alt' => $category->name,'class' => 'w-full h-full object-cover
                   transition-transform duration-300
                   group-hover:scale-105']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cloudinary::image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['public-id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->image),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->name),'class' => 'w-full h-full object-cover
                   transition-transform duration-300
                   group-hover:scale-105']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala40248e8bccff36c9e094fa8227c7bfa)): ?>
<?php $attributes = $__attributesOriginala40248e8bccff36c9e094fa8227c7bfa; ?>
<?php unset($__attributesOriginala40248e8bccff36c9e094fa8227c7bfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala40248e8bccff36c9e094fa8227c7bfa)): ?>
<?php $component = $__componentOriginala40248e8bccff36c9e094fa8227c7bfa; ?>
<?php unset($__componentOriginala40248e8bccff36c9e094fa8227c7bfa); ?>
<?php endif; ?></a>
    </div>
    <h4 class="text-xl font-bold mb-2 text-gray-900"><?php echo e($category->name); ?></h4>
    <p class="text-gray-600 mb-4"><?php echo e($category->description); ?></p>

    <a href="<?php echo e(route('categories.show', $category)); ?>" class="text-primary-600 font-semibold hover:text-primary-700 transition">Ver Productos →</a>
</div><?php /**PATH /var/www/html/resources/views/components/category-card.blade.php ENDPATH**/ ?>