<?php $__env->startSection('title', 'Bienvenido/a - ' . config('app.name')); ?>
<?php $__env->startPush('styles'); ?>
<style>
    .hero-gradient {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<section class="hero-gradient text-white py-20">
    <div class="container mx-auto px-6 text-center">
        <h2 class="text-4xl md:text-6xl font-extrabold leading-tight mb-6">Bienvenido a <?php echo e(config('app.name')); ?></h2>
        <div class="flex items-center justify-center w-full py-16 px-4">
            <img src="<?php echo e(asset('assets/vinylhub-logo.png')); ?>" alt="VinylHub" class="w-full max-w-[280px] sm:max-w-[360px] md:max-w-[360px] lg:max-w-[420px] h-auto">
        </div>
        <p class="text-xl md:text-2xl text-blue-100 mb-8 max-w-3xl mx-auto">Descubre una amplia variedad de productos de calidad. Encuentra lo que buscas al mejor precio.</p>
        <div class="flex flex-wrap justify-center gap-4">
            <a href="<?php echo e(route('products.index')); ?>" class="bg-white text-primary-600 font-bold py-4 px-8 rounded-full hover:bg-gray-100 transition duration-300 ease-in-out transform hover:scale-105">Ver Productos</a>
            <a href="<?php echo e(route('products.on-sale')); ?>" class="border-2 border-white text-white font-bold py-4 px-8 rounded-full hover:bg-white hover:text-primary-600 transition duration-300 ease-in-out">🏷 Ofertas Especiales</a>
        </div>
    </div>
</section>
<!-- Categorías Destacadas -->

<section class="py-16">
    <div class="container mx-auto px-6">
        <h3 class="text-3xl font-bold mb-12 text-center text-gray-900">Nuestras Categorías</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <?php $__empty_1 = true; $__currentLoopData = $featuredCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if (isset($component)) { $__componentOriginald1d747d9a8cee7720616b437e49c144b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald1d747d9a8cee7720616b437e49c144b = $attributes; } ?>
<?php $component = App\View\Components\CategoryCard::resolve(['category' => $category] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('category-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CategoryCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald1d747d9a8cee7720616b437e49c144b)): ?>
<?php $attributes = $__attributesOriginald1d747d9a8cee7720616b437e49c144b; ?>
<?php unset($__attributesOriginald1d747d9a8cee7720616b437e49c144b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald1d747d9a8cee7720616b437e49c144b)): ?>
<?php $component = $__componentOriginald1d747d9a8cee7720616b437e49c144b; ?>
<?php unset($__componentOriginald1d747d9a8cee7720616b437e49c144b); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full text-center py-12">
                <p class="text-gray-500 text-lg">No hay categorías disponibles.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- Productos Destacados -->
<section class="py-16 bg-gray-100">
    <div class="container mx-auto px-6">
        <h3 class="text-3xl font-bold mb-12 text-center text-gray-900">Productos en oferta</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 items-stretch">
            <?php $__empty_1 = true; $__currentLoopData = $discountProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="h-full">
                <?php if (isset($component)) { $__componentOriginalecfc721726b8b5798826c96d529d8b59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecfc721726b8b5798826c96d529d8b59 = $attributes; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProductCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $attributes = $__attributesOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__attributesOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $component = $__componentOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__componentOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full text-center py-12">
                <p class="text-gray-500 text-lg">No hay productos en oferta.</p>
            </div>
            <?php endif; ?>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>