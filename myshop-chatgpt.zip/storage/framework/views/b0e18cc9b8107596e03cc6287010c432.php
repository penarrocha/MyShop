<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php echo $__env->yieldPushContent('meta'); ?>
<title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>

<link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

<!-- Fonts -->
<link rel="preconnect" href="https://fonts.bunny.net">
<link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet">

<!-- Scripts -->
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<script src="<?php echo e(asset('assets/cart.js')); ?>" defer></script>
<?php echo $__env->yieldPushContent('styles'); ?>
<style>
    [x-cloak] {
        display: none !important;
    }
</style><?php /**PATH /var/www/html/resources/views/partials/shared/head.blade.php ENDPATH**/ ?>