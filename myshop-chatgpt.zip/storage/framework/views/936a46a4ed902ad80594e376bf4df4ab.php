<?php
// $breadcrumbs viene del paquete (colección de crumbs)
$items = [];
$position = 1;

foreach ($breadcrumbs as $crumb) {
$items[] = [
'@type' => 'ListItem',
'position' => $position++,
'name' => $crumb->title,
// Schema.org recomienda 'item' con URL. Para el último, puedes usar la URL actual.
'item' => $crumb->url ?: url()->current(),
];
}

$jsonLd = [
'@context' => 'https://schema.org',
'@type' => 'BreadcrumbList',
'itemListElement' => $items,
];
?>


<nav class="mb-6 text-sm text-gray-500" aria-label="Breadcrumb">
    <ol class="flex flex-wrap items-center gap-2">
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $isLast = $loop->last; ?>

        <?php if(!$loop->first): ?>
        <li class="text-gray-400">/</li>
        <?php endif; ?>

        <li class="flex items-center">
            <?php if(!$isLast && $crumb->url): ?>
            <a href="<?php echo e($crumb->url); ?>" class="hover:text-gray-700 transition">
                <?php echo e($crumb->title); ?>

            </a>
            <?php else: ?>
            <span class="text-gray-900 font-medium">
                <?php echo e($crumb->title); ?>

            </span>
            <?php endif; ?>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</nav>


<script type="application/ld+json">
    {
        !!json_encode($jsonLd, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!
    }
</script><?php /**PATH /var/www/html/resources/views/breadcrumbs/tailwind-jsonld.blade.php ENDPATH**/ ?>