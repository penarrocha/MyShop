<div class="bg-white rounded-lg shadow-lg overflow-hidden product-card <?php echo e($class); ?> relative group flex flex-col h-full<?php echo e($product->offer ? ' ring-2 ring-orange-400' : ''); ?>" data-product-card>

    
    <a href="<?php echo e(route('products.show', $product)); ?>" class="absolute inset-0 z-10" aria-label="Ver <?php echo e($product->name); ?>"></a>

    
    <?php if($product->offer): ?>
    <div class="absolute top-0 right-0 bg-gradient-to-r from-orange-500 to-red-500 text-white px-4 py-2 rounded-bl-lg font-bold shadow-lg z-40">
        <span class="text-lg">-<?php echo e($product->offer->discount_percentage); ?>%</span>
    </div>
    <?php endif; ?>

    
    <?php if(isset($topAction)): ?>
    <div class="absolute top-2 left-2 z-40">
        <?php echo e($topAction); ?>

    </div>
    <?php endif; ?>

    
    <div class="h-48 bg-gray-200 flex items-center justify-center overflow-hidden<?php echo e($product->offer ? ' bg-gradient-to-br from-orange-50 to-red-50' : ''); ?> relative" data-product-image>
        <?php if (isset($component)) { $__componentOriginala40248e8bccff36c9e094fa8227c7bfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala40248e8bccff36c9e094fa8227c7bfa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'cloudinary::components.image','data' => ['publicId' => $product->image,'alt' => $product->name,'class' => 'w-full h-full object-covertransition-transform duration-300group-hover:scale-105']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cloudinary::image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['public-id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->image),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->name),'class' => 'w-full h-full object-covertransition-transform duration-300group-hover:scale-105']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala40248e8bccff36c9e094fa8227c7bfa)): ?>
<?php $attributes = $__attributesOriginala40248e8bccff36c9e094fa8227c7bfa; ?>
<?php unset($__attributesOriginala40248e8bccff36c9e094fa8227c7bfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala40248e8bccff36c9e094fa8227c7bfa)): ?>
<?php $component = $__componentOriginala40248e8bccff36c9e094fa8227c7bfa; ?>
<?php unset($__componentOriginala40248e8bccff36c9e094fa8227c7bfa); ?>
<?php endif; ?>
    </div>

    
    <div class="p-6 relative flex flex-col flex-1">
        <h4 class="text-xl font-bold mb-2 text-gray-900"><?php echo e($product->name); ?></h4>
        <p class="text-gray-600 mb-4 line-clamp-3"><?php echo e($product->description); ?></p>

        
        <?php if($product->offer): ?>
        <div class="mb-4">
            <span class="inline-block bg-orange-100 text-orange-800 text-xs px-3 py-1 rounded-full font-semibold">🏷 <?php echo e($product->offer->name); ?></span>
        </div>
        <?php endif; ?>

        
        <div class="mb-4">
            <?php if($product->offer): ?>
            <div class="flex items-baseline gap-2">
                <span class="text-sm text-gray-400 line-through">€ <?php echo e(number_format($product->price, 2)); ?></span>
                <span class="text-2xl font-bold text-orange-600">€ <?php echo e(number_format($product->final_price, 2)); ?></span>
            </div>
            <?php else: ?>
            <span class="text-2xl font-bold text-primary-600">€ <?php echo e(number_format($product->price, 2)); ?></span>
            <?php endif; ?>
        </div>

        
        <div class="mt-auto pt-4 flex flex-col items-center gap-3">

            
            <?php if(isset($actions)): ?>
            <?php echo e($actions); ?>

            <?php else: ?>
            <span class="inline-block bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition cursor-pointer select-none" aria-hidden="true">Ver Detalles</span>
            <?php endif; ?>

            
            <form action="<?php echo e(route('cart.store')); ?>" method="POST" class="relative z-20 md:hidden w-full" data-add-to-cart-form>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                <button type="submit" class="w-full bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 transition font-semibold shadow-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500">🛒 Añadir al carrito</button>
            </form>
        </div>
    </div>

    
    <div class="hidden md:block absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-100 transition z-20 pointer-events-none"></div>

    
    <div class="hidden md:flex absolute inset-0 z-30 items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
        <form action="<?php echo e(route('cart.store')); ?>" method="POST" class="pointer-events-auto" data-add-to-cart-form>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
            <button type="submit" class="bg-blue-600 text-white px-6 py-3 rounded-xl focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500">🛒 Añadir al carrito</button>
        </form>
    </div>
</div><?php /**PATH /var/www/html/resources/views/components/product-card.blade.php ENDPATH**/ ?>