<?php
// Si la vista trae breadcrumb manual, lo usamos. Si no, tomamos la ruta actual.
$name = (isset($breadcrumb['name']) && $breadcrumb['name'] !== null) ? request()->route()?->getName() : false;
$params = $breadcrumb['params'] ?? [];
?>

<?php if($name && Breadcrumbs::exists($name)): ?>
<div class="container mx-auto px-6 pt-6 pb-0 mb-0">
    <?php echo e(Breadcrumbs::render($name, ...$params)); ?>

</div>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/partials/public/breadcrumbs.blade.php ENDPATH**/ ?>